import styled from 'styled-components';

const Wrapper = styled.div`
  width: 260px;
  padding: 13px 15px;
`;

export default Wrapper;
