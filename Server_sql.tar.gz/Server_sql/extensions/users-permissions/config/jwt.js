module.exports = {
  jwtSecret: process.env.JWT_SECRET || '1951b45f-efb7-4cbd-94ea-9fcd27ef6fea'
};