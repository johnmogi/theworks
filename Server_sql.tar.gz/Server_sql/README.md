# Strapi application

A quick description of your strapi application

linux fail - local admin

sudo npm run
